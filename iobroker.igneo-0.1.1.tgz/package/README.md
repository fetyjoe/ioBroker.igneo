# Igneo-Heizung für ioBroker

Version 0.1.1. Der Adapter liest die Messwerte über igneo.pl und stellt sie
als bestätigte, schreibgeschützte ioBroker-Datenpunkte bereit. Er verwendet
das normale Portal-Login und den Leseabruf der Geräteseite. Die Sitzung wird
im Arbeitsspeicher wiederverwendet und nach dem Ablauf neu aufgebaut.

## Installation

Voraussetzungen sind Node.js ab Version 20, js-controller ab 5.0.19, Admin
ab 6.0.0 und eine HTTPS-Verbindung vom ioBroker-Host zu igneo.pl.

Kopiere die mitgelieferte TGZ-Datei in das Home-Verzeichnis des Benutzers,
mit dem du ioBroker verwaltest. Führe auf dem ioBroker-Rechner als dieser
Benutzer die folgenden Befehle aus. Passe bei Bedarf den ioBroker-Pfad an.

```sh
cd /opt/iobroker
npm install "$HOME/iobroker.igneo-0.1.1.tgz"
iobroker add igneo
```

Öffne in ioBroker unter **Instanzen** die Einstellungen von `igneo.0`.
Trage Deinen Igneo-Benutzernamen oder Deine E-Mail sowie Dein Passwort dort ein.
Trage als Gerätenummer die Nummer hinter `/device/` in deinem Igneo-Link ein.
Speichere die
Einstellungen und aktiviere die Instanz. Der Standardabruf läuft alle
60 Sekunden. Zugangsdaten stehen weder im Paket noch in den Datenpunkten.
Das Passwort wird durch ioBroker verschlüsselt gespeichert.

## Datenpunkte für VIS 1

| Datenpunkt | Wert |
| --- | --- |
| `igneo.0.boiler.actualTemperature` | Kesseltemperatur in °C |
| `igneo.0.boiler.targetTemperature` | Berechnete Kessel-Solltemperatur in °C |
| `igneo.0.boiler.returnTemperature` | Kesselrücklauf in °C |
| `igneo.0.boiler.outdoorTemperature` | Außenfühler in °C |
| `igneo.0.pellets.tank` | Pellets im Tank in kg |
| `igneo.0.pellets.today` | Pelletverbrauch seit Tagesbeginn in kg |
| `igneo.0.pellets.total` | Pelletverbrauch gesamt in kg |
| `igneo.0.burner.status` | Brennerstatus als Text |
| `igneo.0.heatingCircuit1.flowTemperature` | Heizkreis 1 Vorlauftemperatur in °C |
| `igneo.0.heatingCircuit1.roomTemperature` | Heizkreis 1 Raumtemperatur in °C |
| `igneo.0.device.alarms` | Anzahl der Alarme |
| `igneo.0.device.online` | Gerätestatus laut Portal inklusive CAN-Verbindung |
| `igneo.0.info.connection` | Portalabruf erfolgreich |
| `igneo.0.info.lastSuccess` | Letzte erfolgreiche Portalantwort als Unix-Zeit in Millisekunden |
| `igneo.0.info.lastTelemetry` | Letzter übernommener Heizungswert als Unix-Zeit in Millisekunden |
| `igneo.0.info.error` | Meldung zum letzten Abruffehler |

In einem VIS-1-HTML-Widget kannst du z. B. direkt
`{igneo.0.boiler.actualTemperature} °C` binden. Bei fehlenden Messwerten
bleiben die zuletzt empfangenen Werte sichtbar. Über `device.online`,
`info.connection` und `info.lastTelemetry` siehst du, ob die Werte noch
aktualisiert werden.

Die Gerätefelder und ihre Umrechnung wurden mit der Geräteseite abgeglichen.
Installation und Anmeldung auf dem Ziel-ioBroker stehen für diese erste
Version noch aus.
