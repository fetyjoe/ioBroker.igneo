'use strict';

const { Adapter } = require('@iobroker/adapter-core');
const { Portal, PortalError } = require('./lib/portal');
const { fields, decode } = require('./lib/measurements');

const channels = {
    info: 'Verbindung zum Igneo-Portal',
    boiler: 'Kessel',
    burner: 'Brenner',
    pellets: 'Pelletverbrauch',
    heatingCircuit1: 'Heizkreis 1',
    device: 'Gerätestatus',
};

const diagnostics = [
    ['info.connection', 'Igneo-Portal erreichbar', 'boolean', 'indicator.connected'],
    ['info.lastSuccess', 'Letzter erfolgreicher Portalabruf (Unix-Zeit in ms)', 'number', 'value.time'],
    ['info.lastTelemetry', 'Letzte Übernahme von Heizungswerten (Unix-Zeit in ms)', 'number', 'value.time'],
    ['info.error', 'Fehlermeldung', 'string', 'text'],
];

class Igneo extends Adapter {
    constructor(options = {}) {
        super({ ...options, name: 'igneo' });
        this.failures = 0;
        this.stopping = false;
        this.on('ready', () => {
            this.active = this.start().catch(() => {
                if (!this.stopping) this.log.error('Igneo-Datenpunkte konnten nicht initialisiert werden.');
            });
        });
        this.on('unload', callback => {
            this.stopping = true;
            clearTimeout(this.timer);
            this.abort?.abort();
            Promise.resolve(this.active)
                .then(() => this.setStateAsync('info.connection', false, true))
                .catch(() => {})
                .finally(callback);
        });
    }

    async createState(id, name, type, role, unit) {
        const common = { name, type, role, read: true, write: false };
        if (unit) common.unit = unit;
        await this.setObjectNotExistsAsync(id, { type: 'state', common, native: {} });
    }

    async start() {
        for (const [id, name] of Object.entries(channels)) {
            await this.setObjectNotExistsAsync(id, { type: 'channel', common: { name }, native: {} });
        }
        for (const [id, name, type, role] of diagnostics) await this.createState(id, name, type, role);
        for (const [id, name, , , role, unit] of fields) {
            const type = role.startsWith('indicator') ? 'boolean' : role === 'text' ? 'string' : 'number';
            await this.createState(id, name, type, role, unit);
        }
        await this.setStateAsync('info.connection', false, true);
        if (this.stopping) return;

        const username = String(this.config.username ?? '').trim();
        const password = this.config.password;
        const deviceId = String(this.config.deviceId ?? '').trim();
        if (!username || typeof password !== 'string' || !password || !/^\d{1,20}$/.test(deviceId)) {
            const message = 'Bitte hinterlege Igneo-Login, Passwort und eine gültige Gerätenummer.';
            await this.setStateAsync('info.error', message, true);
            this.log.warn(message);
            return;
        }
        this.portal = new Portal({ username, password, deviceId });
        const seconds = Number(this.config.pollSeconds);
        this.interval = Number.isFinite(seconds) && seconds > 0 ? Math.max(30, Math.min(3600, seconds)) : 60;
        await this.poll();
    }

    async poll() {
        if (this.stopping) return;
        this.abort = new AbortController();
        let delay = this.interval;
        try {
            const panel = await this.portal.poll(this.abort.signal);
            if (this.stopping) return;
            const values = decode(panel);
            const now = Date.now();
            let hasTelemetry = false;
            for (const [id, value] of Object.entries(values)) {
                const deviceStatus = id.startsWith('device.');
                if (!deviceStatus && values['device.online'] === false) continue;
                await this.setStateAsync(id, value, true);
                hasTelemetry ||= !deviceStatus;
            }
            if (hasTelemetry) await this.setStateAsync('info.lastTelemetry', now, true);
            await this.setStateAsync('info.lastSuccess', now, true);
            await this.setStateAsync('info.error', '', true);
            await this.setStateAsync('info.connection', true, true);
            this.failures = 0;
        } catch (error) {
            if (this.stopping) return;
            const message = error instanceof PortalError ? error.message : 'Abruf vom Igneo-Portal fehlgeschlagen (Netzwerk oder Zeitüberschreitung).';
            this.failures++;
            delay = Math.max(this.interval, Math.min(900, this.interval * 2 ** Math.min(this.failures, 5)));
            if (error.code === 'login') delay = Math.max(delay, 300);
            this.log.warn(message + ' Neuer Versuch in ' + delay + ' s.');
            await this.setStateAsync('info.connection', false, true);
            await this.setStateAsync('info.error', message, true);
        } finally {
            this.abort = undefined;
            if (!this.stopping) {
                this.timer = setTimeout(() => {
                    this.active = this.poll().catch(() => this.log.warn('Igneo-Abruf konnte nicht in ioBroker gespeichert werden.'));
                }, delay * 1000);
            }
        }
    }
}

if (require.main === module) {
    new Igneo();
} else {
    module.exports = options => new Igneo(options);
}
